args <- commandArgs(trailingOnly = FALSE)
fa <- args[grepl("^--file=", args)]
script_dir <- if (length(fa)) dirname(normalizePath(sub("^--file=", "", fa[1]))) else getwd()
source_root <- normalizePath(file.path(script_dir, ".."))
output_dir <- if (basename(source_root) == "05_SOURCE_TRACEABILITY") {
  normalizePath(file.path(source_root, "..", "04_FIGURES"))
} else source_root
source(file.path(script_dir, "figure_helpers.R"))
suppressPackageStartupMessages(library(ggplot2))
nodes <- read.csv(file.path(source_root, "source_data", "FigureS2_high_specificity_flow_nodes.csv"))
edge_input <- read.csv(file.path(source_root, "source_data", "FigureS2_high_specificity_flow_edges.csv"))
edges <- merge(edge_input, nodes[c("id", "x", "y", "w")], by.x = "from_id", by.y = "id")
names(edges)[names(edges) %in% c("x", "y", "w")] <- c("from_x", "from_y", "from_w")
edges <- merge(edges, nodes[c("id", "x", "y", "w")], by.x = "to_id", by.y = "id")
names(edges)[names(edges) %in% c("x", "y", "w")] <- c("to_x", "to_y", "to_w")
p <- ggplot(nodes) +
  geom_segment(data = edges,
    aes(x = from_x + from_w / 2, y = from_y, xend = to_x - to_w / 2, yend = to_y),
    linewidth = .45, color = "#596B78", arrow = grid::arrow(length = grid::unit(2.2, "mm"), type = "closed")) +
  geom_rect(aes(xmin = x - w / 2, xmax = x + w / 2, ymin = y - h / 2, ymax = y + h / 2, fill = group),
    color = "#49606F", linewidth = .45, show.legend = FALSE) +
  geom_text(aes(x = x, y = y, label = label), size = 3.25, lineheight = 1.05, color = "#17242D") +
  scale_fill_manual(values = c(primary = "#E3F1EC", source = "#EAF0F3", phenotype = "#F5F1E7", exclusion = "#F7E9E7")) +
  coord_cartesian(xlim = c(-.5, 12.2), ylim = c(-2.8, 2.7), expand = FALSE, clip = "off") +
  labs(title = "High-specificity comparison flow",
    subtitle = "Discharge-diagnosis text criteria; not independent clinical adjudication") +
  theme_void(base_size = 11) + theme(plot.title = element_text(face = "bold", hjust = .5, color = "#111111"),
    plot.subtitle = element_text(hjust = .5, color = "#333333"), plot.margin = margin(8, 12, 8, 12))
save_figure_set(p, "FigureS2_HighSpecificityFlow", output_dir, 11.2, 6.4)
